#!/xbin/sh

chmod 777 /system/bin/gesture

/system/bin/gesture >> /sdcard/log.txt

echo " --- " >> /sdcard/log.txt

